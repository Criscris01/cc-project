<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Nosotros</title>
  <link rel="stylesheet" href="styles.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&family=Rubik:ital,wght@0,300..900;1,300..900&display=swap" rel="stylesheet">
  <link rel="shortcut icon" href="./images/shotcut/nosotros.ico">

  <!-- Estilos específicos de la página Nosotros -->
  <style>
    .main-nosotros {
      flex: 1;
      padding: 2rem;
      background-color: #C1D3F6;
    }

    .nosotros-card {
      display: flex;
      border-radius: 12px;
      overflow: hidden;
      background-color: #C1D3F6;
      box-shadow: 0 4px 8px rgba(11, 33, 74, 0.12);
      transition: transform 0.3s ease, box-shadow 0.3s ease;
      animation: fadeInUp 0.6s ease both;
      border: 1.5px solid #719BEA;
      margin: 0 auto 3rem auto;
      max-width: 1000px;
    }

    .nosotros-card:hover {
      transform: translateY(-3px);
      box-shadow: 0 6px 12px rgba(21, 63, 142, 0.2);
    }

    .nosotros-image {
      width: 50%;
      background-image: url("./images/about.png");
      background-size: cover;
      background-position: center;
      transition: transform 0.3s ease;
    }

    .nosotros-card:hover .nosotros-image {
      transform: scale(1.05);
    }

    .nosotros-description {
      width: 50%;
      padding: 1rem 1.5rem;
      background-color: #C1D3F6;
      font-family: "Montserrat", sans-serif;
      color: #0B214A;
    }

    .nosotros-description h2 {
      font-size: 1.8rem;
      margin: 0.25rem 0 0.5rem 0;
      font-family: "Rubik", sans-serif;
      font-weight: 500;
      position: relative;
      text-align: center;
    }

    .nosotros-description h2::after {
      content: "";
      position: absolute;
      width: 0;
      height: 1px;
      bottom: -5px;
      left: 0;
      background-color: #2163DE;
      transition: width 0.3s ease;
    }

    .nosotros-card:hover .nosotros-description h2::after {
      width: 100%;
    }

    .nosotros-description p {
      margin: 0.8rem 0;
      line-height: 1.6;
    }

    .mision-vision-container {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 2rem;
      width: 100%;
      max-width: 1000px;
      margin: 0 auto;
    }

    .mision-card,
    .vision-card {
      border-radius: 12px;
      overflow: hidden;
      background-color: #C1D3F6;
      box-shadow: 0 4px 8px rgba(11, 33, 74, 0.12);
      transition: transform 0.3s ease, box-shadow 0.3s ease;
      animation: fadeInUp 0.6s ease both;
      border: 1.5px solid #719BEA;
    }

    .mision-card:hover,
    .vision-card:hover {
      transform: translateY(-3px);
      box-shadow: 0 6px 12px rgba(21, 63, 142, 0.2);
    }

    .mision-description,
    .vision-description {
      padding: 1rem 1.5rem;
      background-color: #C1D3F6;
      text-align: center;
      font-family: "Montserrat", sans-serif;
      color: #0B214A;
    }

    .mision-description h2,
    .vision-description h2 {
      font-size: 1.5rem;
      margin: 0.25rem 0 0.5rem 0;
      font-family: "Rubik", sans-serif;
      font-weight: 500;
      position: relative;
    }

    .mision-description h2::after,
    .vision-description h2::after {
      content: "";
      position: absolute;
      width: 0;
      height: 1px;
      bottom: -5px;
      left: 0;
      background-color: #2163DE;
      transition: width 0.3s ease;
    }

    .mision-card:hover .mision-description h2::after,
    .vision-card:hover .vision-description h2::after {
      width: 100%;
    }

    @keyframes fadeInUp {
      from {
        opacity: 0;
        transform: translateY(20px);
      }

      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    @media (max-width: 768px) {
      .main-nosotros {
        padding: 1rem;
      }

      .nosotros-card {
        flex-direction: column;
        margin: 0 auto 2rem auto;
      }

      .nosotros-image {
        width: 100%;
        height: 200px;
        object-fit: cover;
        object-position: center;
      }

      .nosotros-description {
        width: 100%;
        padding: 0 1rem;
        box-sizing: border-box;
        text-align: left;
      }

      .mision-vision-container {
        display: grid;
        grid-template-columns: 1fr;
        gap: 1.5rem;
        padding: 0;
        /* Cambiado a 0 */
        width: 100%;
        margin: 0 auto;
        /* Asegura centrado */
        justify-items: stretch;
      }

      .mision-vision-container>div {
        width: 100%;
        box-sizing: border-box;
        padding: 1rem;
        /* Añadido padding aquí en lugar del contenedor */
        margin: 0;
        /* Reset de márgenes */
      }
    }
  </style>
</head>

<body>
  <?php include "header.php"; ?>

  <main class="main-nosotros">
    <div class="nosotros-card">
      <div class="nosotros-image"></div>
      <div class="nosotros-description">
        <h2>Conóceme</h2>
        <p>Soy Cristian David Pérez Palacios, estudiante de Ingeniería de Sistemas en la Universidad de Pamplona, apasionado por la tecnología y la educación digital. CC Project nace como mi proyecto final para la asignatura Plataformas Tecnológicas, con el objetivo de transformar horas de estudio en una experiencia educativa clara, accesible y aplicada.</p>
      </div>
    </div>

    <div class="mision-vision-container">
      <div class="mision-card">
        <div class="mision-description">
          <h2>Misión</h2>
          <p>Mi misión es desmitificar los sistemas operativos, capa por capa, para estudiantes y entusiastas de la tecnología. Creo que entender cómo funciona un sistema operativo no debería ser un privilegio de expertos, sino un derecho de todo curioso digital. A través de explicaciones claras, analogías cotidianas y ejemplos prácticos, convierto procesos en historias comprensibles, la memoria en espacios organizados, los hilos en equipos coordinados y los sistemas de archivos en bibliotecas inteligentes, ofreciendo educación tecnológica accesible y sin jerga innecesaria.</p>
        </div>
      </div>
      <div class="vision-card">
        <div class="vision-description">
          <h2>Visión</h2>
          <p>Visualizo un ecosistema digital donde CC Project sea un puente entre la academia y la aplicación real. Aspiro a que esta plataforma sea más que un espacio de consulta: un laboratorio virtual donde estudiantes hispanohablantes comprendan y dominen los fundamentos que impulsan la tecnología moderna. Para 2026, busco que CC Project sea reconocido como un recurso confiable para el primer contacto con los sistemas operativos y como un banco de ejemplos prácticos referenciado por educadores, evolucionando con las tendencias tecnológicas y manteniendo siempre la claridad como bandera.</p>
        </div>
      </div>
    </div>

    </div>
    </div>
    </div>
  </main>

  <?php include "footer.php"; ?>
  <script src="menu.js"></script>
</body>

</html>