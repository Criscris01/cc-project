<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CC Project</title>
  <link rel="stylesheet" href="styles.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&family=Rubik:ital,wght@0,300..900;1,300..900&display=swap" rel="stylesheet">
  <link rel="shortcut icon" href="./images/shotcut/house.ico">

  <!-- Estilos específicos de la página ccproject -->
  <style>
    .main-ccproject {
      flex: 1;
      padding: 2rem;
      background-color: #C1D3F6;
    }

    .welcome-section {
      text-align: center;
      padding: 1rem 2rem;
      background: #C1D3F6;
      border-radius: 12px;
      animation: fadeInUp 0.6s ease both;
      min-height: auto;
      margin-bottom: 2rem;
    }

    .welcome-section h1 {
      margin: 0;
      font-family: "Rubik", sans-serif;
      font-weight: 500;
      color: #0B214A;
      font-size: 2rem;
    }

    .welcome-section p {
      color: #0B214A;
      font-size: 1.1rem;
      line-height: 1.6;
      max-width: 900px;
      margin: 0 auto;
    }

    .topics-container {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 2rem;
      width: 100%;
    }

    .topic-card {
      display: flex;
      flex-direction: column;
      border-radius: 12px;
      overflow: hidden;
      background-color: #C1D3F6;
      box-shadow: 0 6px 16px rgba(11, 33, 74, 0.15);
      transition: transform 0.3s ease, box-shadow 0.3s ease;
      animation: fadeInUp 0.6s ease both;
      align-items: center;
      border: 1.5px solid #719BEA;
    }

    .topic-card:hover {
      transform: translateY(-6px);
      box-shadow: 0 10px 20px rgba(21, 63, 142, 0.25);
    }

    @keyframes fadeInUp {
      from {
        opacity: 0;
        transform: translateY(20px);
      }

      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    .image {
      width: 200px;
      height: 200px;
      border-radius: 50%;
      background-size: cover;
      background-position: center;
      transition: transform 0.3s ease;
      margin-top: 1rem;
    }

    .topic-card:hover .image {
      transform: scale(1.05);
    }

    .description {
      padding: 1.5rem;
      background-color: #C1D3F6;
      text-align: center;
      font-family: "Montserrat", sans-serif;
      color: #0B214A;
      width: 100%;
    }

    .description h2 {
      font-size: 1.3rem;
      margin-bottom: 1rem;
      font-family: "Rubik", sans-serif;
      font-weight: 500;
      position: relative;
    }

    .description h2::after {
      content: "";
      position: absolute;
      width: 0;
      height: 1px;
      bottom: -5px;
      left: 0;
      background-color: #2163DE;
      transition: width 0.3s ease;
    }

    .topic-card:hover .description h2::after {
      width: 100%;
    }

    .btn {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 0.7rem 1.5rem;
      font-size: 1rem;
      border-radius: 100px;
      background: linear-gradient(135deg, #153F8E, #1B51B6);
      color: #FFFFFF;
      font-weight: 500;
      text-decoration: none;
      transition: background 0.3s ease, transform 0.2s ease;
      font-family: "Montserrat", sans-serif;
    }

    .btn::after {
      content: "➜";
      font-size: 1.1rem;
    }

    .btn:hover {
      background: linear-gradient(135deg, #1B51B6, #153F8E);
      transform: scale(1.05);
    }

    @media (max-width: 600px) {
      .image {
        width: 150px;
        height: 150px;
      }

      .description h2 {
        font-size: 1.1rem;
      }

      .btn {
        font-size: 0.9rem;
        padding: 0.5rem 1rem;
      }
    }

    /* Asignación de imágenes de fondo */
    #image1 {
      background-image: url("./images/sistemaoperativo.png");
    }

    #image2 {
      background-image: url("./images/sistemadecomputo.jpg");
    }

    #image3 {
      background-image: url("./images/estructuradesistemaoperativo.jpg");
    }

    #image4 {
      background-image: url("./images/gestiondeprocesos.png");
    }

    #image5 {
      background-image: url("./images/threads.jpg");
    }

    #image6 {
      background-image: url("./images/gestiondememoria.webp");
    }
  </style>
</head>

<body>
  <?php include "header.php"; ?>

  <main class="main-ccproject">
    <section class="welcome-section">
      <h1>¡Descubre el Corazón de la Computación!</h1>
      <p>
        Bienvenidos a CC Project, tu portal interactivo al fascinante mundo de los sistemas operativos. Aquí desentrañamos los misterios que hacen posible que cada clic, cada comando y cada programa cobren vida en tu dispositivo. Navega a través de seis módulos esenciales donde convertimos conceptos complejos en conocimiento digerible y práctico. Desde los cimientos de los sistemas operativos hasta la gestión de memoria, cada recuadro es una puerta a entender la tecnología que usas diariamente.
      </p>
    </section>

    <section class="topics-container">
      <div class="topic-card">
        <div class="image" id="image1"></div>
        <div class="description">
          <h2>Sistemas Operativos</h2>
          <a href="topic-template.php?teme=0" class="btn">Ver más</a>
        </div>
      </div>

      <div class="topic-card">
        <div class="image" id="image2"></div>
        <div class="description">
          <h2>Sistema de Cómputo</h2>
          <a href="topic-template.php?teme=1" class="btn">Ver más</a>
        </div>
      </div>

      <div class="topic-card">
        <div class="image" id="image3"></div>
        <div class="description">
          <h2>Estructura de un SO</h2>
          <a href="topic-template.php?teme=2" class="btn">Ver más</a>
        </div>
      </div>

      <div class="topic-card">
        <div class="image" id="image4"></div>
        <div class="description">
          <h2>Gestión de Procesos</h2>
          <a href="topic-template.php?teme=3" class="btn">Ver más</a>
        </div>
      </div>

      <div class="topic-card">
        <div class="image" id="image5"></div>
        <div class="description">
          <h2>Hilos en Sistemas Operativos</h2>
          <a href="topic-template.php?teme=4" class="btn">Ver más</a>
        </div>
      </div>

      <div class="topic-card">
        <div class="image" id="image6"></div>
        <div class="description">
          <h2>Gestión de Memoria</h2>
          <a href="topic-template.php?teme=5" class="btn">Ver más</a>
        </div>
      </div>
    </section>
  </main>

  <?php include "footer.php"; ?>
  <script src="menu.js"></script>
</body>

</html>