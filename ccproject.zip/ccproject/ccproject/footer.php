<?php
echo '
<footer class="footer">
  <div class="footer-logo">
    <a href="ccproject.php" class="footer-logo-link"><h1 class="footer-logo-title">CC PROJECT</h1></a>
  </div>

  <div class="footer-content">
    <div class="footer-section">
      <h3>Nuestra esencia</h3>
      <p>Este proyecto fue desarrollado con código, café y mucha curiosidad.</p>
    </div>

    <div class="footer-section">
      <h3>Enlaces útiles</h3>
      <ul>
        <li><a href="#">Política de privacidad</a></li>
        <li><a href="#">Términos de uso</a></li>
        <li><a href="#">Contáctanos</a></li>
      </ul>
    </div>

    <div class="footer-section">
      <h3>Redes sociales</h3>
      <div class="social-icons">
        <a href="#" aria-label="Instagram"><ion-icon name="logo-instagram"></ion-icon></a>
        <a href="#" aria-label="Facebook"><ion-icon name="logo-facebook"></ion-icon></a>
        <a href="#" aria-label="Twitter"><ion-icon name="logo-twitter"></ion-icon></a>
        <a href="#" aria-label="WhatsApp"><ion-icon name="logo-whatsapp"></ion-icon></a>
      </div>
    </div>
  </div>

  <p class="footer-copy">&copy; ' . date("Y") . ' CC Project. Todos los derechos reservados.</p>

  <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
  <script src="menu.js"></script>
</footer>';
