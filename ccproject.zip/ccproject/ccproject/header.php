<?php
echo '<header class="banner">
    <div class="logo-container">
      <a id="logo" href="ccproject.php"><h1>CC PROJECT</h1></a>
    </div>

    <div class="menu-container">
      <nav class="navbar" aria-label="Navegación principal">
        <ul id="menu">
          <li><a href="ccproject.php">INICIO</a></li>
          <li class="dropdown">
            <a href="javascript:void(0)">CONTENIDO</a>
            <ul class="submenu">
              <li><a href="topic-template.php?teme=0">Sistemas Operativos</a></li>
              <li><a href="topic-template.php?teme=1">Sistema de Cómputo</a></li>
              <li><a href="topic-template.php?teme=2">Estructura de un SO</a></li>
              <li><a href="topic-template.php?teme=3">Gestión de Procesos</a></li>
              <li><a href="topic-template.php?teme=4">Hilos en Sistemas Operativos</a></li>
              <li><a href="topic-template.php?teme=5">Gestión de Memoria</a></li>
            </ul>
          </li>
          <li><a href="videos.php">CURIOSOS</a></li>
          <li><a href="about.php">SOBRE MI</a></li>
        </ul>
      </nav>
    </div>
    <script src="menu.js"></script>
  </header>';
