function adjustLayout() {
  const isSmallScreen = window.innerWidth <= 768;
  const mainContent = document.querySelector('.main-content');

  if (mainContent) {
    if (isSmallScreen) {
      mainContent.style.gridTemplateAreas = '"content-top" "sidebar" "content-bot"';
    } else {
      mainContent.style.gridTemplateAreas = '"content-top content-top" "content-bot sidebar"';
    }
  }
}

function initMobileMenu() {
  const dropdowns = document.querySelectorAll('.dropdown');
  

  if (window.innerWidth > 768) return;
  
  dropdowns.forEach(dropdown => {
    const link = dropdown.querySelector('a');
    
    if (link) {

      link.removeEventListener('click', handleDropdownClick);

      link.addEventListener('click', handleDropdownClick);
    }
  });
  
  function handleDropdownClick(e) {
    e.preventDefault();
    e.stopPropagation();
    
    const dropdown = this.closest('.dropdown');
    const isActive = dropdown.classList.contains('active');
    
    document.querySelectorAll('.dropdown').forEach(d => {
      d.classList.remove('active');
    });
    

    if (!isActive) {
      dropdown.classList.add('active');
    }
  }
  

  document.addEventListener('click', function(e) {
    if (!e.target.closest('.dropdown') && !e.target.closest('.submenu')) {
      document.querySelectorAll('.dropdown').forEach(d => {
        d.classList.remove('active');
      });
    }
  });
}


document.addEventListener('DOMContentLoaded', function() {
  adjustLayout();
  initMobileMenu();
  

  window.addEventListener('resize', function() {
    adjustLayout();
    

    if (window.innerWidth > 768) {
      document.querySelectorAll('.dropdown').forEach(d => {
        d.classList.remove('active');
      });
    } else {
      initMobileMenu();
    }
  });

  document.querySelectorAll('.submenu a').forEach(link => {
    link.addEventListener('click', function() {
      setTimeout(() => {
        document.querySelectorAll('.dropdown').forEach(d => {
          d.classList.remove('active');
        });
      }, 100);
    });
  });
});