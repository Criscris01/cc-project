<?php
include "topics.php"; ?>
<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Temas</title>
  <link rel="stylesheet" href="styles.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&family=Rubik:ital,wght@0,300..900;1,300..900&display=swap" rel="stylesheet">
  <link rel="shortcut icon" href="./images/shotcut/libro.ico">

  <!-- Estilos específicos de la página de Temas -->
  <style>
    .main-content {
      flex: 1;
      display: grid;
      grid-template-areas:
        "content-top content-top"
        "content-bot sidebar";
      grid-template-columns: 3fr 1fr;
      gap: 20px;
      padding: 1rem;
    }

    .sidebar {
      grid-area: sidebar;
      width: 100%;
      animation: fadeInUp 0.6s ease both;
      align-self: start;
    }

    .sidebar.hidden {
      display: none;
    }

    .sidebar a {
      color: black;
      text-decoration: none;
      font-family: "Montserrat", sans-serif;
    }

    .sidebar-content {
      background: #C1D3F6;
      border-radius: 0px;
      max-width: 100%;
      padding: 1rem 1.5rem;
      height: fit-content;
      border-left: 2px solid #0B214A;
    }

    .sidebar-content h2 {
      font-family: "Rubik", sans-serif;
      font-weight: 500;
      color: #0B214A;
      margin: 0.25rem 0 0.5rem 0;
    }

    .content-top {
      grid-area: content-top;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 1rem 2rem;
      background: #C1D3F6;
      border-radius: 12px;
      animation: fadeInUp 0.6s ease both;
      text-align: center;
      min-height: auto;
    }

    .content-top h1 {
      margin: 0;
      font-family: "Rubik", sans-serif;
      font-weight: 500;
      color: #0B214A;
      font-size: 2rem;
    }

    .content-bot {
      grid-area: content-bot;
      padding: 1rem 1.5rem;
      font-family: "Montserrat", sans-serif;
      color: #0B214A;
      background: #C1D3F6;
      border-radius: 12px;
      box-shadow: 0 6px 16px rgba(11, 33, 74, 0.2);
      animation: fadeInUp 0.6s ease both;
      margin: 0;
      margin-right: -5px;
      border: 1.5px solid #719BEA;
    }

    .content-bot h1:first-child,
    .content-bot h2:first-child,
    .content-bot h3:first-child,
    .content-bot h4:first-child,
    .content-bot h5:first-child,
    .content-bot h6:first-child {
      margin-top: 0.25rem;
      margin-bottom: 0.5rem;
    }

    .content-bot a {
      position: relative;
      text-decoration: none;
      color: #0B214A;
      transition: color 0.3s ease;
    }

    .content-bot a::after {
      content: "";
      position: absolute;
      width: 0;
      height: 2px;
      bottom: -2px;
      left: 0;
      background-color: #0B214A;
      transition: width 0.3s ease;
    }

    .content-bot a:hover {
      color: #1B51B6;
    }

    .content-bot a:hover::after {
      width: 100%;
    }

    @keyframes fadeInUp {
      from {
        opacity: 0;
        transform: translateY(20px);
      }

      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    @media (max-width: 768px) {
      .main-content {
        grid-template-areas:
          "content-top"
          "sidebar"
          "content-bot";
        grid-template-columns: 1fr;
      }
    }

    #video {
      width: 70%;
      height: 25rem;
    }

    #video iframe {
      width: 100%;
      height: 100%;
    }
  </style>
</head>

<body>
  <?php include "header.php"; ?>

  <main class="main-content">
    <section class="content-top" id="contenido">
      <h1><?php echo $temas[$_GET["teme"]][0]; ?></h1>
    </section>

    <section class="sidebar">
      <div class="sidebar-content">
        <h2><strong>Tabla de Contenido</strong></h2>
        <?php echo $temas[$_GET["teme"]][1]; ?>
      </div>
    </section>

    <section class="content-bot">
      <?php echo $temas[$_GET["teme"]][2]; ?>
    </section>
  </main>

  <?php include "footer.php"; ?>
  <script src="menu.js"></script>
</body>

</html>