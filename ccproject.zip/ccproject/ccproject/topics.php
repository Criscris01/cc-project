<?php
$temas = [
    [
        "Sistemas Operativos",
        '<ul>
    <li><a href="#definicion"><strong>Definición de Sistema Operativo</strong></a></li>
    <li><a href="#funciones"><strong>Funciones Principales del Sistema Operativo</strong></a></li>
    <li><a href="#clasificacion"><strong>Clasificación de los Sistemas Operativos</strong></a></li>
    <li><a href="#glosario"><strong>Glosario</strong></a></li>
    <li><a href="#referencia"><strong>Referencias</strong></a></li>
</ul>',
        '<h2 id="definicion">Definición de Sistema Operativo</h2>
<p>Un <strong>sistema operativo (SO)</strong> es un <strong>software fundamental</strong> que actúa como intermediario entre el usuario y el <strong>hardware</strong> del sistema de cómputo. Su función principal es <strong>gestionar los recursos del hardware</strong> y proporcionar un entorno en el que los programas puedan ejecutarse eficientemente.</p>
<p>El sistema operativo es el <strong>"puente"</strong> entre el usuario, las aplicaciones y el hardware.</p>
<p><strong>Ejemplos de sistemas operativos:</strong></p>
<ul>
    <li><strong>Para computadoras:</strong> Windows, Linux, macOS.</li>
    <li><strong>Para dispositivos móviles:</strong> Android, iOS.</li>
    <li><strong>Para sistemas embebidos:</strong> FreeRTOS, VxWorks.</li>
</ul>

<h2 id="funciones">Funciones Principales del Sistema Operativo</h2>

<h3>a) Gestión de Procesos</h3>
<ul>
    <li><strong>Asigna y controla</strong> la ejecución de programas en la <strong>CPU</strong>.</li>
    <li>Coordina la ejecución de <strong>procesos concurrentes</strong> y la asignación de recursos.</li>
    <li><strong>Ejemplo:</strong> En Windows, el <strong>Administrador de Tareas</strong> permite ver y gestionar procesos en ejecución.</li>
</ul>

<h3>b) Gestión de Memoria</h3>
<ul>
    <li>Controla el uso de la <strong>RAM</strong>, asegurando que cada programa tenga el espacio necesario.</li>
    <li>Implementa mecanismos de <strong>memoria virtual</strong> para optimizar el rendimiento.</li>
    <li><strong>Ejemplo:</strong> En sistemas modernos, la memoria RAM se complementa con memoria virtual en el disco.</li>
</ul>

<h3>c) Gestión de Almacenamiento</h3>
<ul>
    <li>Organiza y administra los archivos en <strong>discos duros y SSD</strong>.</li>
    <li>Maneja <strong>sistemas de archivos</strong> como NTFS, FAT32, EXT4.</li>
    <li><strong>Ejemplo:</strong> En Windows, el <strong>Explorador de Archivos</strong> permite gestionar archivos y carpetas.</li>
</ul>

<h3>d) Gestión de Dispositivos</h3>
<ul>
    <li>Administra los <strong>periféricos</strong> conectados al sistema, como teclado, ratón, impresoras, etc.</li>
    <li>Usa <strong>controladores de dispositivo (drivers)</strong> para la comunicación entre hardware y software.</li>
    <li><strong>Ejemplo:</strong> El <strong>Administrador de Dispositivos</strong> en Windows permite gestionar hardware conectado.</li>
</ul>

<h3>e) Interfaz de Usuario</h3>
<ul>
    <li>Permite la interacción del usuario con el sistema operativo.</li>
    <li><strong>Tipos:</strong>
        <ul>
            <li><strong>CLI (Command Line Interface):</strong> Interacción mediante comandos (Ejemplo: Terminal de Linux, CMD en Windows).</li>
            <li><strong>GUI (Graphical User Interface):</strong> Interacción mediante ventanas, iconos y menús (Ejemplo: Escritorio de Windows, macOS).</li>
        </ul>
    </li>
</ul>

<h2 id="clasificacion">Clasificación de los Sistemas Operativos</h2>

<h3>a) Monotarea vs. Multitarea</h3>
<ul>
    <li><strong>Monotarea:</strong> Solo permite ejecutar un programa a la vez (Ejemplo: <strong>MS-DOS</strong>).</li>
    <li><strong>Multitarea:</strong> Permite la ejecución de múltiples programas simultáneamente (Ejemplo: <strong>Windows, Linux</strong>).</li>
</ul>

<h3>b) Monousuario vs. Multiusuario</h3>
<ul>
    <li><strong>Monousuario:</strong> Solo un usuario puede acceder al sistema a la vez (Ejemplo: Windows en una PC personal).</li>
    <li><strong>Multiusuario:</strong> Permite que varios usuarios accedan al sistema simultáneamente (Ejemplo: <strong>Unix</strong>, servidores de red).</li>
</ul>

<h3>c) Sistemas en Tiempo Real</h3>
<ul>
    <li>Diseñados para aplicaciones críticas que requieren <strong>tiempos de respuesta garantizados</strong>.</li>
    <li><strong>Ejemplo:</strong> Sistemas en aviones, máquinas de control industrial.</li>
</ul>

<h3>d) Sistemas Embebidos</h3>
<ul>
    <li>Diseñados para dispositivos con <strong>funciones específicas</strong>.</li>
    <li><strong>Ejemplo:</strong> SO en microcontroladores de electrodomésticos y automóviles.</li>
</ul>

<h3>e) Sistemas Operativos Móviles</h3>
<ul>
    <li>Optimizados para dispositivos portátiles con batería y pantallas táctiles.</li>
    <li><strong>Ejemplo:</strong> <strong>Android, iOS</strong>.</li>
</ul>

<h2 id="glosario">Glosario</h2>
<ul>
    <li><strong>Android:</strong> Sistema operativo basado en Linux diseñado para dispositivos móviles, desarrollado por Google y optimizado para pantallas táctiles.</li>
    <li><strong>CPU (Unidad Central de Procesamiento):</strong> Componente principal de un sistema informático que ejecuta instrucciones de programas.</li>
    <li><strong>Driver:</strong> Software que permite la comunicación entre el sistema operativo y un dispositivo de hardware.</li>
    <li><strong>GUI (Graphical User Interface):</strong> Interfaz de usuario basada en elementos visuales como iconos y ventanas.</li>
    <li><strong>Kernel:</strong> Núcleo del sistema operativo que gestiona los recursos del hardware y la comunicación con el software.</li>
    <li><strong>Memoria RAM (Random Access Memory):</strong> Tipo de memoria volátil que almacena datos temporales mientras el sistema está en uso.</li>
    <li><strong>Minix:</strong> Sistema operativo basado en Unix diseñado para propósitos educativos y conocido por inspirar el desarrollo de Linux.</li>
    <li><strong>Multitarea:</strong> Capacidad de un sistema operativo para ejecutar múltiples programas simultáneamente.</li>
    <li><strong>Sistema de Archivos:</strong> Estructura que organiza y almacena archivos en dispositivos de almacenamiento.</li>
    <li><strong>SO (Sistema Operativo):</strong> Software fundamental que gestiona los recursos del hardware y proporciona servicios a los programas.</li>
    <li><strong>Terminal:</strong> Interfaz de línea de comandos que permite la interacción directa con el sistema operativo.</li>
    <li><strong>Tiempo Real:</strong> Sistemas operativos que responden a eventos en un tiempo predecible, usados en aplicaciones críticas.</li>
</ul>

        <h2 id="referencia">Referencias</h2>
        <ul>
            <li><a href="https://mega.nz/file/BZ5XwDyD#FUrz_jZzECoYQLlIiA5f-inVUTsgupmCPRLdhKMAdCQ">Material de estudio</a></li>
            <li><a href="https://www.ibm.com/es-es/think/topics/operating-systems">¿Qué es un sistema operativo?</a></li>
            <li><a href="https://concepto.de/sistema-operativo/">Concepto de Sistema Operativo</a></li>
            <li><a href="https://www.godaddy.com/resources/es/digitalizacion/sistema-operativo-que-es">Sistema Operativo: Qué es, Fundamentos y Características</a></li>
            <li><a href="http://nuc.edu/noticias/sistemas-operativos/">Sistemas Operativos: Qué son, Evolución y Principales SO</a></li>
        </ul>',
    ],
    [
        "Sistema de Cómputo",
        '<ul>
        <li><a href="#que-es"><strong>¿Qué es un Sistema de Cómputo?</strong></a></li>
        <li><a href="#componentes"><strong>Componentes de un Sistema de Cómputo</strong></a></li>
        <li><a href="#funcionamiento"><strong>Funcionamiento de un Sistema de Cómputo</strong></a></li>
        <li><a href="#sistema-operativo"><strong>¿Qué es un Sistema Operativo?</strong></a></li>
        <li><a href="#relacion-hardware"><strong>Relación entre el Sistema Operativo y el Hardware</strong></a></li>
        <li><a href="#ejemplos-practicos"><strong>Ejemplos Prácticos</strong></a></li>
        <li><a href="#glosario"><strong>Glosario</strong></a></li>
        <li><a href="#referencia"><strong>Referencias</strong></a></li>
    </ul>',
        '<h2 id="que-es">¿Qué es un Sistema de Cómputo?</h2>
    <p>Un <strong>sistema de cómputo</strong> es el conjunto de dispositivos electrónicos, físicos (<strong>hardware</strong>) y programas lógicos (<strong>software</strong>) que, bajo la coordinación de un <strong>sistema operativo</strong>, trabajan de manera integrada para procesar, almacenar, transmitir y proteger información.</p>
    <p>En la actualidad, los sistemas de cómputo abarcan desde computadoras personales hasta <strong>sistemas embebidos</strong>, <strong>servidores en la nube</strong> y <strong>dispositivos móviles inteligentes</strong>.</p>

    <h2 id="componentes">Componentes de un Sistema de Cómputo</h2>
    
    <h3>• Hardware:</h3>
    <ul>
        <li><strong>CPU (Unidad Central de Procesamiento):</strong> núcleo del sistema, capaz de ejecutar instrucciones. Hoy día se distinguen <strong>procesadores multinúcleo</strong> y unidades de procesamiento especializado como las <strong>GPU</strong> y <strong>TPU (Tensor Processing Unit)</strong> para IA.</li>
        
        <li><strong>Memoria RAM:</strong> memoria de acceso aleatorio que almacena temporalmente instrucciones y datos en ejecución. Versiones actuales incluyen <strong>DDR4/DDR5</strong>.</li>
        
        <li><strong>Almacenamiento:</strong>
            <ul>
                <li><strong>HDD</strong> (disco duro magnético).</li>
                <li><strong>SSD</strong> (unidad de estado sólido) con mayor velocidad y durabilidad.</li>
                <li><strong>Almacenamiento en la nube</strong> (ej. Google Drive, AWS S3).</li>
            </ul>
        </li>
        
        <li><strong>GPU (Unidad de Procesamiento Gráfico):</strong> maneja cálculos gráficos y actualmente es clave en <strong>procesamiento paralelo</strong> para IA y big data.</li>
        
        <li><strong>Periféricos de Entrada:</strong> teclado, ratón, escáner, cámaras, sensores IoT.</li>
        
        <li><strong>Periféricos de Salida:</strong> monitor, impresora, proyectores, dispositivos de realidad aumentada/virtual.</li>
        
        <li><strong>Periféricos de Entrada/Salida:</strong> pantallas táctiles, discos externos, tarjetas de red.</li>
    </ul>

    <h3>• Software:</h3>
    <ul>
        <li><strong>De sistema:</strong> incluye el sistema operativo, controladores y utilidades que permiten el funcionamiento básico del hardware.</li>
        
        <li><strong>De aplicación:</strong> programas que resuelven necesidades específicas: navegadores web, procesadores de texto, aplicaciones móviles, IDEs de programación, plataformas de IA.</li>
        
        <li><strong>De middleware:</strong> capa intermedia que permite comunicación entre aplicaciones y hardware/sistema (ej. servidores de aplicaciones, contenedores como <strong>Docker</strong>).</li>
    </ul>

    <h2 id="funcionamiento">Funcionamiento de un Sistema de Cómputo</h2>
    <ul>
        <li>El usuario interactúa mediante <strong>interfaces gráficas (GUI)</strong> o <strong>interfaces de línea de comandos (CLI)</strong>.</li>
        
        <li>El sistema operativo coordina y administra los recursos físicos (procesador, memoria, almacenamiento).</li>
        
        <li>Los programas acceden al hardware mediante <strong>llamadas al sistema (system calls)</strong>.</li>
        
        <li>En sistemas actuales, se integran conceptos como <strong>virtualización</strong>, <strong>seguridad</strong>, <strong>gestión de energía</strong> y <strong>conectividad en red</strong>.</li>
    </ul>

    <h2 id="sistema-operativo">¿Qué es un Sistema Operativo?</h2>
    <p>Es el <strong>software esencial</strong> que actúa como intermediario entre el usuario y el hardware, gestionando los recursos de cómputo, facilitando la ejecución de programas y garantizando aspectos de <strong>seguridad</strong>, <strong>eficiencia</strong> y <strong>multitarea</strong>.</p>
    <p>En la actualidad, los sistemas operativos incluyen soporte para <strong>virtualización</strong>, <strong>administración en la nube</strong>, <strong>entornos distribuidos</strong> y <strong>dispositivos móviles</strong>.</p>

    <h2 id="relacion-hardware">Relación entre el Sistema Operativo y el Hardware</h2>
    <ul>
        <li><strong>Controladores de dispositivos:</strong> traducen instrucciones del SO a señales que entiende el hardware.</li>
        
        <li><strong>Administración de procesos:</strong> coordinación de múltiples tareas y asignación de CPU.</li>
        
        <li><strong>Gestión de memoria:</strong> asignación eficiente, protección de procesos y uso de <strong>memoria virtual</strong>.</li>
        
        <li><strong>Gestión de almacenamiento:</strong> organización de archivos en <strong>sistemas de ficheros</strong> (ej. NTFS, ext4, APFS).</li>
        
        <li><strong>Gestión de red:</strong> permite comunicación en entornos locales y en la nube.</li>
        
        <li><strong>Seguridad y autenticación:</strong> control de acceso a recursos, cifrado y políticas de permisos.</li>
    </ul>

    <h2 id="ejemplos-practicos">Ejemplos Prácticos</h2>
    <ul>
        <li><strong>Conexión de un periférico</strong> → el sistema operativo detecta el hardware vía <strong>Plug and Play</strong>, instala o solicita un controlador y habilita el uso.</li>
        
        <li><strong>Visualización del Administrador de Tareas (Windows)</strong> o <strong>Monitor de Recursos (Linux/macOS)</strong> para analizar procesos en ejecución.</li>
        
        <li><strong>Gestión de conflictos de hardware</strong> → el sistema operativo administra prioridades y recursos para evitar fallos.</li>
    </ul>

    <h2 id="glosario">Glosario</h2>
    <ul>
        <li><strong>Sistema de Cómputo:</strong> Integración de hardware, software y redes para procesar datos.</li>
        
        <li><strong>CPU:</strong> Procesador principal que ejecuta instrucciones.</li>
        
        <li><strong>GPU:</strong> Procesador especializado en gráficos y cómputo paralelo.</li>
        
        <li><strong>TPU:</strong> Procesador diseñado para aprendizaje automático.</li>
        
        <li><strong>RAM:</strong> Memoria de acceso aleatorio que almacena datos temporales.</li>
        
        <li><strong>ROM:</strong> Memoria de solo lectura, contiene firmware esencial.</li>
        
        <li><strong>Firmware:</strong> Software básico almacenado en chips que controla funciones esenciales del hardware.</li>
        
        <li><strong>Sistema Operativo (SO):</strong> Software que administra recursos y permite la interacción entre usuario, hardware y aplicaciones.</li>
        
        <li><strong>Virtualización:</strong> Tecnología que permite ejecutar múltiples sistemas operativos en un mismo hardware.</li>
        
        <li><strong>Middleware:</strong> Capa de software que conecta aplicaciones y sistemas.</li>
        
        <li><strong>Multitarea:</strong> Capacidad de ejecutar múltiples procesos simultáneamente.</li>
        
        <li><strong>Cloud Computing:</strong> Uso de recursos informáticos a través de Internet (almacenamiento, servidores, aplicaciones).</li>
        
        <li><strong>Controlador (Driver):</strong> Programa que permite que el SO gestione un dispositivo.</li>
        
        <li><strong>Interfaz de Usuario:</strong> Medio de comunicación entre el sistema y el usuario (CLI, GUI, VUI –interfaz de voz–).</li>
    </ul>

        <h2 id="referencia">Referencias</h2> 
        <ul> 
            <li><a href="https://mega.nz/file/9dAEjQJa#lkD4xrkksPDL0hfniTAjfechF9CDx8zSsG6UukAAF4g">Material de estudio</a></li>
            <li><a href="https://gatitasistemas.weebly.com/iquestque-es-un-sistema-de-computo.html">¿Que es un Sistema de Computo?</a></li> 
            <li><a href="https://materiaslti2015.wordpress.com/2015/11/16/sistemas-de-computo/">Sistemas de Computo</a></li> 
        </ul>',
    ],

    [
        "Estructura de un Sistema Operativo",
        '<ul>
        <li><a href="#introduccion"><strong>Introducción</strong></a></li>
        <li><a href="#componentes"><strong>Componentes Principales de un SO</strong></a></li>
        <li><a href="#modelos"><strong>Modelos de Estructura de un SO</strong></a></li>
        <li><a href="#ejemplos-reales"><strong>Ejemplos Reales</strong></a></li>
        <li><a href="#ejemplo-practico"><strong>Ejemplo Práctico</strong></a></li>
        <li><a href="#glosario"><strong>Glosario</strong></a></li>
        <li><a href="#referencia"><strong>Referencias</strong></a></li>
    </ul>',
        '<h2 id="introduccion">Introducción</h2>
    <p>Un <strong>sistema operativo (SO)</strong> no es un programa único, sino un <strong>conjunto organizado de módulos</strong> que trabajan en conjunto para gestionar recursos y ofrecer servicios a los usuarios y aplicaciones.</p>
    <p>La <strong>estructura de un SO</strong> determina cómo se organizan, interactúan y comunican esos módulos. Esta organización es fundamental porque afecta al <strong>rendimiento</strong>, la <strong>seguridad</strong> y la <strong>facilidad de mantenimiento</strong>.</p>

    <h2 id="componentes">Componentes Principales de un SO</h2>
    <ul>
        <li><strong>Núcleo (Kernel):</strong> parte central que controla <strong>CPU</strong>, <strong>memoria</strong>, dispositivos de <strong>E/S</strong> y <strong>llamadas al sistema</strong>.</li>
        
        <li><strong>Gestión de procesos:</strong> administra la <strong>ejecución</strong>, <strong>planificación</strong> y <strong>sincronización</strong> de procesos.</li>
        
        <li><strong>Gestión de memoria:</strong> controla la <strong>asignación</strong>, <strong>liberación</strong> y <strong>protección</strong> de la memoria principal.</li>
        
        <li><strong>Gestión de archivos:</strong> organiza y proporciona <strong>acceso seguro</strong> a los datos en almacenamiento secundario.</li>
        
        <li><strong>Gestión de dispositivos de entrada/salida (E/S):</strong> comunica hardware con aplicaciones.</li>
        
        <li><strong>Sistema de protección y seguridad:</strong> garantiza <strong>acceso seguro</strong> y <strong>controlado</strong> a recursos.</li>
    </ul>

    <h2 id="modelos">Modelos de Estructura de un SO</h2>
    
    <h3>• Estructura Monolítica:</h3>
    <ul>
        <li>Todo el <strong>sistema operativo</strong> corre como un <strong>único programa</strong> en modo kernel.</li>
        <li><strong>Ejemplo:</strong> MS-DOS, primeras versiones de UNIX.</li>
        <li><strong>Ventajas:</strong> rápido, menos capas de comunicación.</li>
        <li><strong>Desventajas:</strong> difícil de mantener, un fallo puede tumbar todo el sistema.</li>
    </ul>

    <h3>• Estructura en Capas:</h3>
    <ul>
        <li>Organizado en <strong>niveles jerárquicos</strong>. Cada capa interactúa con la inferior y superior.</li>
        <li><strong>Ejemplo:</strong> THE (Dijkstra), OS/2.</li>
        <li><strong>Ventajas:</strong> modularidad, facilita depuración.</li>
        <li><strong>Desventajas:</strong> sobrecarga y complejidad.</li>
    </ul>

    <h3>• Microkernel:</h3>
    <ul>
        <li>El <strong>kernel es mínimo</strong>, gestiona solo lo esencial (procesos, memoria, comunicación entre procesos).</li>
        <li><strong>Ejemplo:</strong> Mach, Minix, QNX.</li>
        <li><strong>Ventajas:</strong> mayor seguridad y estabilidad.</li>
        <li><strong>Desventajas:</strong> menor rendimiento por comunicación entre procesos.</li>
    </ul>

    <h3>• Estructura Híbrida:</h3>
    <ul>
        <li>Combina <strong>microkernel</strong> y <strong>monolítico</strong>.</li>
        <li><strong>Ejemplo:</strong> Windows NT/10/11, Linux, macOS.</li>
        <li><strong>Ventajas:</strong> equilibrio entre rendimiento y modularidad.</li>
        <li><strong>Desventajas:</strong> complejidad en el diseño.</li>
    </ul>

    <h3>• Estructura Modular:</h3>
    <ul>
        <li>Usa <strong>módulos cargables dinámicamente</strong>, facilitando extensibilidad.</li>
        <li><strong>Ejemplo:</strong> Linux, Solaris.</li>
        <li><strong>Ventajas:</strong> flexibilidad, personalización.</li>
        <li><strong>Desventajas:</strong> requiere gestión cuidadosa de dependencias.</li>
    </ul>

    <h2 id="ejemplos-reales">Ejemplos Reales</h2>
    <ul>
        <li><strong>Linux (Modular/Híbrido):</strong> se pueden cargar y descargar módulos como drivers con <code>modprobe</code>.</li>
        
        <li><strong>Windows (Híbrido):</strong> combina microkernel con servicios en modo usuario para mejorar rendimiento.</li>
        
        <li><strong>Android:</strong> basado en Linux modular, con servicios propios (HAL, ART, Binder).</li>
        
        <li><strong>MacOS:</strong> basado en XNU, que mezcla Mach (microkernel) y BSD (monolítico).</li>
    </ul>

    <h2 id="ejemplo-practico">Ejemplo Práctico</h2>
    
    <h3>Linux (Ubuntu):</h3>
    <p><strong>Comando:</strong></p>
    <pre><code>lsmod</code></pre>
    <p>→ Lista los <strong>módulos del kernel</strong> cargados en memoria.</p>

    <h3>Windows:</h3>
    <p><strong>Uso del Administrador de tareas</strong> → ver procesos y servicios en ejecución.</p>

    <h2 id="glosario">Glosario</h2>
    <ul>
        <li><strong>Kernel:</strong> núcleo central del SO.</li>
        
        <li><strong>Proceso:</strong> programa en ejecución que requiere recursos.</li>
        
        <li><strong>Módulo:</strong> componente independiente que se integra al SO.</li>
        
        <li><strong>Microkernel:</strong> diseño de núcleo reducido que delega servicios al espacio de usuario.</li>
        
        <li><strong>Híbrido:</strong> estructura que mezcla características de kernel monolítico y microkernel.</li>
        
        <li><strong>E/S (Entrada/Salida):</strong> comunicación entre hardware y sistema.</li>
        
        <li><strong>Driver:</strong> software que permite la comunicación entre el SO y un dispositivo físico.</li>
    </ul>
        
        <h2 id="referencia">Referencias</h2>
        <ul> 
            <li><a href="https://mega.nz/file/MV5FXCTR#ZTA1lfbKPuf9v2Eq4tTYz8PT9DCu9DsU1uPdQ9qcF1Y">Material de estudio</a></li> 
            <li><a href="https://somebooks.es/capitulo-4-elementos-y-estructura-del-sistema-operativo-procesos/3/">Elementos y estructura del sistema operativo</a></li> 
            <li><a href="https://www.fing.edu.uy/tecnoinf/mvd/cursos/so/material/teo/so03-estructura_sist_oper.pdf">Estructura de los sistemas Operativos</a></li> 
        </ul>',
    ],

    [
        "Gestión de Procesos",
        '<ul>
        <li><a href="#definicion"><strong>Definición</strong></a></li>
        <li><a href="#conceptos-fundamentales"><strong>Conceptos Fundamentales</strong></a></li>
        <li><a href="#ciclo-vida"><strong>Ciclo de Vida de un Proceso</strong></a></li>
        <li><a href="#estructura-proceso"><strong>Estructura de un Proceso (PCB)</strong></a></li>
        <li><a href="#planificacion"><strong>Planificación de Procesos</strong></a></li>
        <li><a href="#sincronizacion"><strong>Sincronización de Procesos</strong></a></li>
        <li><a href="#interbloqueo"><strong>Interbloqueo</strong></a></li>
        <li><a href="#tipos-procesos"><strong>Tipos de Procesos</strong></a></li>
        <li><a href="#creacion-eliminacion"><strong>Creación y Eliminación de Procesos</strong></a></li>
        <li><a href="#jerarquia"><strong>Jerarquía de Procesos</strong></a></li>
        <li><a href="#asignacion-recursos"><strong>Asignación de Recursos</strong></a></li>
        <li><a href="#glosario"><strong>Glosario</strong></a></li>
        <li><a href="#referencia"><strong>Referencias</strong></a></li>
    </ul>',

        '<h2 id="definicion">Definición</h2>
    <p>Un <strong>proceso</strong> es una instancia de un programa en ejecución que posee su propio <strong>espacio de memoria</strong>, <strong>estado</strong> y <strong>contexto</strong>. Requiere recursos del sistema como <strong>CPU</strong>, <strong>memoria</strong>, dispositivos de entrada y salida, así como mecanismos de comunicación y control.</p>
    <p>Un <strong>programa</strong>, por el contrario, es un conjunto de instrucciones pasivo almacenado en disco que se convierte en proceso únicamente cuando el sistema operativo lo carga y ejecuta.</p>

    <h2 id="conceptos-fundamentales">Conceptos Fundamentales</h2>
    
       <ul>
        <li><strong>Programa:</strong> Conjunto de instrucciones escritas en un lenguaje de programación que permanecen inactivas hasta que son ejecutadas. <strong>Ejemplo:</strong> un archivo .exe antes de ser abierto.</li>
        <li><strong>Proceso:</strong> Programa en ejecución que necesita recursos del sistema. Es activo, ocupa memoria y es administrado por el sistema operativo.</li>
    </ul>
    
    <h3>• Diferencias entre Programa y Proceso</h3>
    <ul>
        <li>El <strong>programa es pasivo</strong>, el <strong>proceso es activo</strong>.</li>
        <li>Un programa se convierte en proceso al ser cargado en memoria.</li>
        <li>Un proceso necesita recursos y posee un <strong>contexto de ejecución</strong>.</li>
    </ul>

    <h2 id="ciclo-vida">Ciclo de Vida de un Proceso</h2>
    
    <h3>• Estados del Proceso</h3>
    <ul>
        <li><strong>Nuevo (New):</strong> El proceso está siendo creado.</li>
        <li><strong>Listo (Ready):</strong> Se encuentra cargado en memoria esperando turno en la CPU.</li>
        <li><strong>Ejecutando (Running):</strong> La CPU está ejecutando el proceso.</li>
        <li><strong>Esperando/Bloqueado (Waiting):</strong> El proceso espera por un recurso o evento externo.</li>
        <li><strong>Terminado (Terminated):</strong> Finalizó su ejecución.</li>
    </ul>
    
    <h3>• Transiciones entre Estados</h3>
    <ul>
        <li><strong>Nuevo → Listo:</strong> proceso preparado para ejecutar.</li>
        <li><strong>Listo → Ejecutando:</strong> el planificador asigna CPU.</li>
        <li><strong>Ejecutando → Esperando:</strong> requiere un recurso externo.</li>
        <li><strong>Esperando → Listo:</strong> el recurso está disponible.</li>
        <li><strong>Ejecutando → Listo:</strong> interrupción del planificador.</li>
        <li><strong>Ejecutando → Terminado:</strong> finaliza ejecución.</li>
    </ul>

    <h2 id="estructura-proceso">Estructura de un Proceso (PCB)</h2>
    <p>El <strong>Process Control Block (PCB)</strong> es la estructura que contiene toda la información necesaria para administrar un proceso.</p>
    
    <h3>• Componentes del PCB</h3>
    <ul>
        <li><strong>PID:</strong> Identificador único del proceso.</li>
        <li><strong>Estado del proceso:</strong> Estado dentro del ciclo de vida.</li>
        <li><strong>Contador de programa:</strong> Próxima instrucción a ejecutar.</li>
        <li><strong>Registros:</strong> Información temporal usada por el proceso.</li>
        <li><strong>Información de planificación:</strong> Prioridad, tiempos de CPU.</li>
        <li><strong>Gestión de memoria:</strong> Segmentos/páginas asignados.</li>
        <li><strong>Entrada/Salida:</strong> Dispositivos y archivos asociados.</li>
        <li><strong>Recursos asignados:</strong> Recursos de hardware/software utilizados.</li>
        <li><strong>Comunicación entre procesos:</strong> Pipes, colas de mensajes, etc.</li>
    </ul>

    <h2 id="planificacion">Planificación de Procesos</h2>
    <p>La planificación determina qué proceso será ejecutado por la CPU.</p>
    
    <h3>• Algoritmos de Planificación</h3>
    <ul>
        <li><strong>FCFS (First Come First Served):</strong> Atiende en orden de llegada.</li>
        <li><strong>SJF (Shortest Job First):</strong> Ejecuta primero el proceso más corto.</li>
        <li><strong>Round Robin:</strong> Usa un <strong>quantum</strong> para repartir tiempo de CPU.</li>
        <li><strong>Prioridad:</strong> Ejecuta primero los procesos con mayor prioridad.</li>
    </ul>

    <h2 id="sincronizacion">Sincronización de Procesos</h2>
    <p>La sincronización evita condiciones de carrera en el acceso a recursos compartidos.</p>
    
    <h3>• Mecanismos de Sincronización</h3>
    <ul>
        <li><strong>Semáforos:</strong> Controlan acceso mediante <code>wait()</code> y <code>signal()</code>.</li>
        <li><strong>Monitores:</strong> Garantizan acceso ordenado a variables compartidas.</li>
        <li><strong>Mutex:</strong> Permiten exclusión mutua en secciones críticas.</li>
    </ul>
    
    <h3>• Problemas Comunes</h3>
    <ul>
        <li>Condiciones de carrera.</li>
        <li>Necesidad de orden y exclusión mutua.</li>
    </ul>

    <h2 id="interbloqueo">Interbloqueo</h2>
    <p>Ocurre cuando varios procesos quedan esperando indefinidamente recursos retenidos por otros.</p>
    
    <h3>• Condiciones del Interbloqueo</h3>
    <ul>
        <li>Exclusión mutua.</li>
        <li>Retención y espera.</li>
        <li>No apropiación.</li>
        <li>Espera circular.</li>
    </ul>
    
    <h3>• Manejo del Interbloqueo</h3>
    <ul>
        <li>Prevención mediante reglas del sistema.</li>
        <li>Algoritmo del banquero.</li>
        <li>Detección y recuperación.</li>
    </ul>

    <h2 id="tipos-procesos">Tipos de Procesos</h2>
    <ul>
        <li><strong>Independientes:</strong> No dependen de otros procesos ni comparten recursos.</li>
        <li><strong>Interdependientes:</strong> Comparten recursos y requieren comunicación.</li>
        <li><strong>Procesos de Usuario:</strong> Iniciados por aplicaciones del usuario.</li>
        <li><strong>Procesos del Sistema:</strong> Generados por el sistema operativo.</li>
        <li><strong>Procesos en Primer Plano:</strong> Requieren interacción directa con el usuario.</li>
        <li><strong>Procesos en Segundo Plano:</strong> Se ejecutan sin intervención del usuario.</li>
    </ul>

    <h2 id="creacion-eliminacion">Creación y Eliminación de Procesos</h2>
    
    <h3>• Creación</h3>
    <ul>
        <li><strong>Linux/UNIX:</strong> <code>fork()</code></li>
        <li><strong>Windows:</strong> <code>CreateProcess()</code></li>
    </ul>
    
    <h3>• Eliminación</h3>
    <ul>
        <li><strong>Voluntaria:</strong> usuario o proceso decide terminar.</li>
        <li><strong>Forzada:</strong> el sistema operativo finaliza un proceso.</li>
    </ul>

    <h2 id="jerarquia">Jerarquía de Procesos</h2>
    <ul>
        <li><strong>Padre:</strong> Proceso que crea otro.</li>
        <li><strong>Hijo:</strong> Proceso generado por el padre.</li>
    </ul>
    <p>Los sistemas suelen formar <strong>árboles jerárquicos</strong> de procesos.</p>

    <h2 id="asignacion-recursos">Asignación de Recursos</h2>
    <p>El sistema operativo administra los recursos que utiliza un proceso:</p>
    <ul>
        <li><strong>CPU</strong> mediante el <strong>scheduler</strong>.</li>
        <li><strong>Memoria</strong> mediante segmentación o paginación.</li>
        <li><strong>Entradas y salidas</strong> mediante controladores.</li>
    </ul>

    <h2 id="glosario">Glosario</h2>
    <ul>
        <li><strong>Proceso:</strong> Programa en ejecución.</li>
        <li><strong>Programa:</strong> Conjunto de instrucciones almacenadas.</li>
        <li><strong>PCB:</strong> Estructura con información del proceso.</li>
        <li><strong>PID:</strong> Identificador único de un proceso.</li>
        <li><strong>Foreground/Background:</strong> Procesos en primer y segundo plano.</li>
        <li><strong>Scheduler:</strong> Planificador de CPU.</li>
        <li><strong>Semáforo:</strong> Variable usada para sincronización.</li>
        <li><strong>Mutex:</strong> Exclusión mutua.</li>
        <li><strong>Interbloqueo:</strong> Espera circular entre procesos.</li>
    </ul>

    <h2 id="referencia">Referencias</h2> 
    <ul> 
        <li><a href="https://mega.nz/file/MdJhwawK#DDWsyL8sGd2NfN8vIL5w5wQGVz4acL2Ad0QltH9brGE">Material de estudio 1</a></li> 
        <li><a href="https://mega.nz/file/gNAVlKjK#0ZpGLeWL9sj_dYYcQfk1tNed_cNWBJE5bO-L4BQ4jLc">Material de estudio 2</a></li> 
        <li><a href="https://www.ibm.com/docs/es/aix/7.1.0?topic=administration-process-management">Gestión de procesos</a></li> 
    </ul>',
    ],

    [
        "Hilos en Sistemas Operativos",
        '<ul>
        <li><a href="#hilos"><strong>¿Qué es un hilo (thread)?</strong></a></li>
        <li><a href="#sincronizacion-evaluacion"><strong>Sincronización y Evaluación</strong></a></li>
        <li><a href="#glosario"><strong>Glosario</strong></a></li>
          <li><a href="#referencia"><strong>Referencias</strong></a></li>

    </ul>',
        '<h2 id="hilos">¿Qué es un hilo (thread)?</h2>

    <p>Un <strong>hilo</strong> es la unidad más pequeña de procesamiento que puede ser ejecutada por un sistema operativo. Es una <strong>secuencia de instrucciones</strong> dentro de un proceso que se puede ejecutar independientemente de otras secuencias.</p>
    
    <h3>• Diferencia entre proceso e hilo:</h3>
    <ul>
        <li><strong>Proceso:</strong> Conjunto de instrucciones con su propio <strong>espacio de memoria</strong> y recursos del sistema. Es pesado en términos de recursos.</li>
        <li><strong>Hilo:</strong> Parte de un proceso. Comparte el <strong>espacio de direcciones</strong> del proceso padre y sus recursos, lo que permite una <strong>comunicación más rápida</strong> pero requiere sincronización.</li>
    </ul>
    
    <h3>• Ventajas del uso de hilos:</h3>
    <ul>
        <li><strong>Menor sobrecarga:</strong> Los hilos comparten memoria, lo que reduce el uso de recursos.</li>
        <li><strong>Mayor rendimiento en sistemas multiprocesador.</strong></li>
        <li><strong>Comunicación rápida entre hilos.</strong></li>
        <li><strong>Responsividad:</strong> Mejora la capacidad de respuesta de aplicaciones (por ejemplo, interfaces gráficas).</li>
    </ul>
    
    <h3>• Modelos de hilos:</h3>
    <ul>
        <li><strong>Modelo a nivel de usuario:</strong> Todos los hilos se gestionan en espacio de usuario, sin intervención directa del sistema operativo. Más eficientes, pero no aprovechan los núcleos múltiples.</li>
        <li><strong>Modelo a nivel de kernel:</strong> El sistema operativo gestiona directamente los hilos. Permite <strong>paralelismo real</strong>, pero con más sobrecarga.</li>
        <li><strong>Modelo híbrido:</strong> Combina ambos. Usa múltiples hilos a nivel de usuario que se asignan a múltiples hilos a nivel de kernel. Equilibra <strong>eficiencia y rendimiento</strong>.</li>
    </ul>
    
    <h3>• Aplicaciones de hilos:</h3>
    <ul>
        <li><strong>Navegadores web</strong> (un hilo para cada pestaña).</li>
        <li><strong>Servidores web</strong> (manejo de múltiples peticiones simultáneas).</li>
        <li><strong>Juegos</strong> (IA, gráficos y sonido en hilos separados).</li>
        <li><strong>IDEs y software multimedia.</strong></li>
    </ul>

    <h2 id="sincronizacion-evaluacion">Sincronización y Evaluación</h2>
    
    <h3>• Sincronización de hilos:</h3> 
    <p>Es el proceso que asegura que los hilos que comparten recursos lo hagan sin conflictos, garantizando <strong>consistencia</strong>.</p>
    
    <h3>• Problemas comunes en sistemas multihilo:</h3>
    <ul>
        <li><strong>Condición de carrera:</strong> Ocurre cuando dos o más hilos acceden a una sección crítica al mismo tiempo y el resultado depende del orden de ejecución.</li>
        <li><strong>Interbloqueo (deadlock):</strong> Situación en la que dos o más hilos esperan indefinidamente recursos que están siendo ocupados por otros hilos.</li>
        <li><strong>Hambre (starvation):</strong> Algunos hilos nunca acceden a recursos debido a la constante prioridad de otros hilos.</li>
    </ul>
    
    <h3>• Mecanismos de sincronización:</h3>
    <ul>
        <li><strong>Semáforo (Semaphore):</strong> Contador entero que se utiliza para controlar el acceso a recursos compartidos. Puede ser <strong>binario (0/1)</strong> o con <strong>conteo</strong>.</li>
        <li><strong>Mutex (Mutual Exclusion):</strong> Variable o estructura usada para permitir el acceso exclusivo a una sección crítica.</li>
        <li><strong>Monitores:</strong> Abstracción de alto nivel que permite manejar sincronización y exclusión mutua de manera automática dentro de lenguajes como Java.</li>
    </ul>
    
    <h3>• Ejemplo: problema del productor-consumidor</h3>
    <ul>
        <li><strong>Productor:</strong> Genera datos y los pone en un buffer.</li>
        <li><strong>Consumidor:</strong> Toma datos del buffer.</li>
        <li>Se requiere <strong>sincronización</strong> para evitar que el productor llene el buffer cuando está lleno o que el consumidor lo lea cuando está vacío.</li>
    </ul>

    <h2 id="glosario">Glosario</h2>
    
    <ul>
    <li><strong>Hilo (Thread):</strong> Secuencia de ejecución dentro de un proceso.</li>
    <li><strong>Proceso:</strong> Programa en ejecución con su propio espacio de memoria.</li>
    <li><strong>Concurrencia:</strong> Capacidad de ejecutar múltiples tareas de forma lógica simultánea.</li>
    <li><strong>Paralelismo:</strong> Ejecución simultánea real de múltiples tareas en múltiples núcleos.</li>
    <li><strong>Modelo a nivel de usuario:</strong> Gestión de hilos desde el espacio de usuario sin intervención del kernel.</li>
    <li><strong>Modelo a nivel de kernel:</strong> Gestión directa de hilos por parte del sistema operativo.</li>
    <li><strong>Modelo híbrido:</strong> Combina la gestión de hilos en usuario y kernel.</li>
    <li><strong>Responsividad:</strong> Capacidad de una aplicación de responder rápidamente al usuario.</li>
    <li><strong>Multitarea:</strong> Ejecución de varias tareas al mismo tiempo por el sistema operativo.</li>
    <li><strong>Contexto (de ejecución):</strong> Información necesaria para gestionar un hilo o proceso, como registros y punteros.</li>
    <li><strong>Sincronización:</strong> Coordinación de la ejecución de hilos para evitar conflictos de acceso a recursos.</li>
    <li><strong>Condición de carrera:</strong> Error que ocurre cuando dos hilos acceden simultáneamente a una sección crítica sin sincronización.</li>
    <li><strong>Sección crítica:</strong> Fragmento de código donde se accede a recursos compartidos.</li>
    <li><strong>Interbloqueo (Deadlock):</strong> Estado en el que varios hilos se bloquean esperando recursos entre ellos.</li>
    <li><strong>Hambre (Starvation):</strong> Situación donde un hilo no accede nunca a un recurso porque otros siempre lo hacen primero.</li>
    <li><strong>Semáforo:</strong> Contador para controlar acceso concurrente a recursos.</li>
    <li><strong>Mutex:</strong> Herramienta de exclusión mutua que solo permite que un hilo acceda a la vez a una sección crítica.</li>
    <li><strong>Monitor:</strong> Abstracción de sincronización que encapsula variables y procedimientos sincronizados.</li>
    <li><strong>Productor-Consumidor:</strong> Problema clásico de sincronización que requiere control de acceso a un buffer compartido.</li>
</ul>
        
        <h2 id="referencia">Referencias</h2> 
        <ul> 
            <li><a href="https://mega.nz/file/tY5jDaZL#hC2GOpqcGHUq8Lk-So1XG2F4sxIDRa6gX5pvICb1l8A">Material de estudio</a></li> 
            <li><a href="https://www.lenovo.com/co/es/glosario/hilo/?srsltid=AfmBOorOmWu407Sp_T26UtEGhYldoEs5M-XURjYDO9TNVuPRobhUphyX">¿Qué es un hilo en la computación?</a></li> 
            <li><a href="https://repositorio-uapa.cuaed.unam.mx/repositorio/moodle/pluginfile.php/3084/mod_resource/content/1/UAPA-Hilos/index.html">Hilos</a></li> 
        </ul>',
    ],

    [
        "Gestión de Memoria",
        '<ul>
        <li><a href="#definicion-memoria"><strong>Definición de Memoria en un Sistema Informático</strong></a></li>
        <li><a href="#importancia-gestion"><strong>Importancia de la Gestión Eficiente</strong></a></li>
        <li><a href="#tipos-gestion"><strong>Tipos de Gestión de Memoria</strong></a></li>
        <li><a href="#memoria-principal"><strong>Memoria Principal (RAM)</strong></a></li>
        <li><a href="#jerarquia-memoria"><strong>Jerarquía de la Memoria</strong></a></li>
        <li><a href="#tipos-asignacion"><strong>Tipos de Asignación de Memoria</strong></a></li>
        <li><a href="#metodos-asignacion"><strong>Métodos de Asignación</strong></a></li>
        <li><a href="#fragmentacion"><strong>Fragmentación de la Memoria</strong></a></li>
        <li><a href="#algoritmos-reemplazo"><strong>Algoritmos de Reemplazo de Páginas</strong></a></li>
        <li><a href="#problemas-comunes"><strong>Problemas Comunes</strong></a></li>
        <li><a href="#optimizacion"><strong>Optimización del Uso de la Memoria</strong></a></li>
        <li><a href="#memoria-virtual"><strong>Memoria Virtual</strong></a></li>
        <li><a href="#impacto-rendimiento"><strong>Impacto en el Rendimiento</strong></a></li>

        <li><a href="#glosario"><strong>Glosario</strong></a></li>
        <li><a href="#referencia"><strong>Referencias</strong></a></li>
    </ul>',

        '<h2 id="definicion-memoria">Definición de Memoria en un Sistema Informático</h2>
    <p>La <strong>memoria</strong> en un sistema informático se refiere al componente que almacena datos y programas en tiempo de ejecución para que la <strong>CPU</strong> pueda acceder a ellos rápidamente. Es esencial para el funcionamiento adecuado de cualquier sistema informático.</p>

    <h2 id="importancia-gestion">Importancia de la Gestión Eficiente de la Memoria</h2>
    <p>La <strong>gestión eficiente de la memoria</strong> es crucial para garantizar un rendimiento óptimo del sistema. Un mal manejo de la memoria puede llevar a problemas como la <strong>fragmentación de la memoria</strong>, el <strong>agotamiento de recursos</strong> y la <strong>ralentización del sistema</strong>.</p>

    <h2 id="tipos-gestion">Tipos de Gestión de Memoria</h2>
    <ul>
        <li><strong>Memoria contigua:</strong> Cada proceso recibe un bloque continuo de memoria.
            <ul>
                <li><strong>Ventajas:</strong> Simple y rápida.</li>
                <li><strong>Desventajas:</strong> Fragmentación interna y externa.</li>
            </ul>
        </li>
        <li><strong>Memoria no contigua:</strong> El proceso puede ser cargado en diferentes bloques de memoria física no consecutivos.
            <ul>
                <li><strong>Ventajas:</strong> Mejor aprovechamiento del espacio.</li>
                <li><strong>Desventajas:</strong> Complejidad en la gestión.</li>
            </ul>
        </li>
    </ul>

    <h2 id="memoria-principal">Memoria Principal</h2>
    
    <h3>• Definición de memoria principal (RAM)</h3>
    <p>La <strong>memoria principal (RAM)</strong> es un componente físico del hardware de una computadora donde se almacenan los programas en ejecución y los datos con los que la CPU trabaja directamente. Es <strong>volátil</strong>, lo que significa que pierde su contenido cuando se apaga la computadora.</p>
    <p>La <strong>RAM</strong> es crucial para el rendimiento del sistema, ya que determina la cantidad de datos que pueden ser accesibles para la CPU en cualquier momento dado.</p>
    
    <h3>• Organización de la memoria principal</h3>
    <p>En la mayoría de los sistemas informáticos, la memoria principal está organizada en forma de una serie de <strong>celdas direccionables individualmente</strong>, donde cada celda tiene una dirección única que se utiliza para acceder a los datos almacenados en ella. Esto permite un acceso rápido y eficiente a los datos por parte de la CPU.</p>

    <h2 id="jerarquia-memoria">Jerarquía de la Memoria</h2>
    <ul>
        <li><strong>Memoria Caché</strong></li>
        <li><strong>RAM (memoria principal)</strong></li>
        <li><strong>Almacenamiento secundario</strong> (discos duros)</li>
        <li><strong>Almacenamiento terciario</strong> (cintas, backups en la nube)</li>
    </ul>

    <h2 id="tipos-asignacion">Tipos de Asignación de Memoria</h2>
    <ul>
        <li><strong>Asignación dinámica:</strong> La memoria se asigna a los procesos mientras se ejecutan, y se libera al finalizar.</li>
        <li><strong>Swapping:</strong> Cuando la memoria principal se llena, los procesos se intercambian entre la RAM y el disco duro (memoria secundaria).</li>
    </ul>

    <h2 id="metodos-asignacion">Métodos de Asignación de Memoria Principal</h2>
    
     <ul>
        <li><strong>Particionamiento fijo:</strong> En este método, la memoria principal se divide en particiones de tamaño fijo, y cada partición se asigna a un proceso específico. Esto puede llevar a un uso ineficiente de la memoria si los procesos no utilizan toda la partición asignada</li>
        <li><strong>Particionamiento dinámico:</strong> A diferencia del particionamiento fijo, en el particionamiento dinámico, las particiones se crean y se asignan dinámicamente a medida que se solicitan por los procesos. Esto puede ayudar a optimizar el uso de la memoria al asignar particiones del tamaño exacto que necesita cada proceso</li>
        <li><strong>Paginación:</strong> En la paginación, la memoria se divide en bloques de tamaño fijo llamados páginas, y los procesos se dividen en fragmentos de tamaño igual llamados marcos de página. Esto permite una gestión más flexible de la memoria al asignar memoria física a los procesos según sea necesario.</li>
    </ul>

    <h2 id="fragmentacion">Fragmentación de la Memoria</h2>
    
    <ul>
        <li><strong>Fragmentación interna:</strong> Ocurre cuando hay espacio no utilizado dentro de una partición asignada a un proceso. Esto puede ocurrir, por ejemplo, cuando un proceso solicita una cantidad específica de memoria, pero se le asigna una partición que es más grande de lo necesario.</li>
        <li><strong>Fragmentación externa:</strong> Ocurre cuando hay suficiente espacio libre en total, pero está fragmentado en bloques más pequeños que no son lo suficientemente grandes para satisfacer las solicitudes de asignación de memoria. Esto puede dificultar la asignación de memoria a procesos nuevos.</li>

    </ul>

    <h2 id="algoritmos-reemplazo">Algoritmos de Reemplazo de Páginas</h2>
    
<ul>
        <li><strong>FIFO (First In, First Out):</strong> Este algoritmo reemplaza la página más antigua en la memoria. Es simple de implementar, pero puede no ser óptimo en términos de rendimiento, ya que puede eliminar páginas útiles antes de tiempo.</li>
        <li><strong>LRU (Least Recently Used):</strong> Este algoritmo reemplaza la página que no se ha accedido durante el período de tiempo más largo. Es más complejo de implementar, pero puede proporcionar un mejor rendimiento al mantener en memoria las páginas que se utilizan con más frecuencia.</li>
        <li><strong>Optimal:</strong> Este algoritmo reemplaza la página que no se utilizará durante el período de tiempo más largo en el futuro. Aunque teóricamente proporciona el mejor rendimiento, puede ser difícil de implementar en la práctica debido a la necesidad de predecir el futuro acceso a las páginas.</li>
    </ul>

    <h2 id="problemas-comunes">Problemas Comunes de la Memoria Principal</h2>
    <ul>
        <li><strong>Contención de memoria:</strong> Ocurre cuando varios procesos compiten por los mismos recursos de memoria.</li>
        <li><strong>Fragmentación:</strong> Tanto interna como externa, que afecta la eficiencia de la memoria.</li>
    </ul>

    <h2 id="optimizacion">Optimización del Uso de la Memoria Principal</h2>
    <ul>
        <li><strong>Técnicas de swapping:</strong> Intercambiar procesos a la memoria secundaria cuando no hay suficiente espacio en la RAM.</li>
        <li><strong>Uso de algoritmos de reemplazo de páginas:</strong> FIFO, LRU, y otros.</li>
        <li><strong>Memoria compartida:</strong> Facilita la comunicación entre procesos sin duplicar la cantidad de memoria utilizada.</li>
    </ul>

    <h2 id="memoria-virtual">Memoria Virtual</h2>
    
    <h3>• Definición de memoria virtual</h3>
    <p>La <strong>memoria virtual</strong> es una técnica que permite que un sistema operativo ejecute programas que son más grandes que la cantidad de memoria física disponible. Utiliza una combinación de <strong>memoria RAM</strong> y espacio de almacenamiento en disco para almacenar y recuperar datos de manera transparente para el usuario.</p>
    <p>Esto permite ejecutar programas más grandes de lo que sería posible con solo la memoria física disponible.</p>
    
    <h3>• Ventajas</h3>
    <p>Permite que varios programas se ejecuten simultáneamente sin limitarse por la cantidad de RAM.</p>
    
    <h3>• Paginación y segmentación</h3>
    <ul>
        <li><strong>Paginación:</strong> En la paginación, la memoria virtual y física se dividen en bloques de tamaño fijo llamados <strong>páginas</strong>. Esto facilita la gestión de la memoria al permitir que el sistema operativo administre la memoria física y virtual de manera más eficiente.</li>
        <li><strong>Segmentación:</strong> La segmentación divide la memoria en <strong>segmentos lógicos</strong> más grandes que representan partes lógicas del programa, como el código, los datos y la pila. Esto puede ayudar a organizar y estructurar los programas de manera más efectiva.</li>
    </ul>
    
    <h3>• Ventajas y desventajas de la memoria virtual</h3>
    <ul>
        <li><strong>Ventajas:</strong> La memoria virtual permite ejecutar programas más grandes que la cantidad de memoria física disponible, lo que mejora la utilización de los recursos del sistema y permite ejecutar una mayor cantidad de procesos simultáneamente. También facilita la gestión de la memoria al permitir que el sistema operativo maneje de manera transparente la asignación de memoria física y virtual.</li>
        <li><strong>Desventajas:</strong> La implementación de memoria virtual introduce una sobrecarga adicional en el sistema debido a la necesidad de administrar tanto la memoria física como el almacenamiento en disco. Esto puede resultar en una degradación del rendimiento si se utiliza en exceso, ya que el acceso a la memoria virtual en disco es mucho más lento que el acceso a la memoria física.</li>
    </ul>
    
    <h3>• Técnicas de asignación de espacio en disco</h3>
    <ul>
        <li><strong>Swapping:</strong> En el swapping, bloques de datos enteros se transfieren entre la memoria principal y el almacenamiento secundario según sea necesario. Esto permite liberar espacio en la memoria principal al mover datos menos utilizados al almacenamiento en disco.</li>
        <li><strong>Paginación bajo demanda:</strong> En la paginación bajo demanda, solo se transfieren páginas de datos individuales entre la memoria principal y el almacenamiento secundario según sea necesario. Esto puede ayudar a optimizar el uso de la memoria al reducir la cantidad de datos que se transfieren entre la memoria principal y el almacenamiento en disco.</li>
    </ul>
    
    <h3>• Espacio de direcciones virtuales y físicas</h3>
    <ul>
        <li><strong>Espacio de direcciones virtuales:</strong> El espacio de direcciones virtuales es el conjunto de direcciones que un programa puede usar para acceder a la memoria. Es independiente de la cantidad de memoria física disponible en el sistema, lo que permite ejecutar programas que son más grandes que la cantidad de memoria física disponible.</li>
        <li><strong>Espacio de direcciones físicas:</strong> El espacio de direcciones físicas es el conjunto de direcciones que corresponden a la memoria física disponible en el sistema. Es limitado por la cantidad de memoria física instalada en el sistema.</li>
    </ul>

    <h2 id="impacto-rendimiento">Impacto en el Rendimiento</h2>
    <ul>
        <li><strong>Overhead:</strong> El proceso de paginación genera cierto overhead que puede afectar el rendimiento.</li>
        <li><strong>Thrashing:</strong> Ocurre cuando se intercambian constantemente páginas entre la RAM y el disco debido a falta de memoria real.</li>
    </ul>

    <h2 id="glosario">Glosario</h2>
<ul>
    <li><strong>Memoria:</strong> Componente que almacena datos y programas en tiempo de ejecución para acceso rápido de la CPU.</li>
    <li><strong>RAM (Memoria Principal):</strong> Memoria volátil donde se almacenan programas y datos en ejecución.</li>
    <li><strong>Memoria Caché:</strong> Memoria de alta velocidad que almacena datos usados frecuentemente.</li>
    <li><strong>Almacenamiento Secundario:</strong> Dispositivos de almacenamiento no volátil como discos duros.</li>
    <li><strong>Almacenamiento Terciario:</strong> Sistemas de almacenamiento a largo plazo como cintas o backups en la nube.</li>
    <li><strong>Memoria Contigua:</strong> Bloques continuos de memoria asignados a un proceso.</li>
    <li><strong>Memoria No Contigua:</strong> Bloques de memoria física no consecutivos asignados a un proceso.</li>
    <li><strong>Fragmentación Interna:</strong> Espacio no utilizado dentro de una partición asignada.</li>
    <li><strong>Fragmentación Externa:</strong> Bloques libres de memoria demasiado pequeños para satisfacer solicitudes.</li>
    <li><strong>Asignación Dinámica:</strong> Memoria que se asigna a procesos mientras se ejecutan y se libera al finalizar.</li>
    <li><strong>Swapping:</strong> Intercambio de procesos entre RAM y almacenamiento secundario.</li>
    <li><strong>Particionamiento Fijo:</strong> División de memoria en particiones de tamaño fijo.</li>
    <li><strong>Particionamiento Dinámico:</strong> Creación de particiones según necesidades de los procesos.</li>
    <li><strong>Paginación:</strong> División de memoria en bloques de tamaño fijo llamados páginas.</li>
    <li><strong>Marco de Página:</strong> Fragmento de tamaño igual en paginación para asignación de memoria.</li>
    <li><strong>FIFO (First In, First Out):</strong> Algoritmo que reemplaza la página más antigua en memoria.</li>
    <li><strong>LRU (Least Recently Used):</strong> Algoritmo que reemplaza la página menos usada recientemente.</li>
    <li><strong>Algoritmo Óptimo:</strong> Algoritmo teórico que reemplaza la página que no se usará por más tiempo.</li>
    <li><strong>Contención de Memoria:</strong> Competencia de varios procesos por recursos de memoria.</li>
    <li><strong>Memoria Virtual:</strong> Técnica que combina RAM y almacenamiento en disco para expandir memoria.</li>
    <li><strong>Segmentación:</strong> División de memoria en segmentos lógicos según partes del programa.</li>
    <li><strong>Paginación bajo Demanda:</strong> Transferencia de páginas individuales según necesidad.</li>
    <li><strong>Espacio de Direcciones Virtuales:</strong> Direcciones que un programa puede usar, independientes de la memoria física.</li>
    <li><strong>Espacio de Direcciones Físicas:</strong> Direcciones correspondientes a la memoria física instalada.</li>
    <li><strong>Overhead:</strong> Carga adicional generada por procesos como la paginación.</li>
    <li><strong>Thrashing:</strong> Intercambio constante de páginas entre RAM y disco por falta de memoria.</li>
</ul>

     <h2 id="referencia">Referencias</h2> 
        <ul> 
            <li><a href="https://mega.nz/file/Ucg1xCwS#UPFWa3AmUypwoAr7vz2aNrrp2B4bhZ84e4n-10cHFAo">Material de estudio</a></li> 
            <li><a href="https://www.lenovo.com/mx/es/glosario/gestor-memoria/?srsltid=AfmBOoqdxJQuOe6W1pXSJ28V2__2X04UJ_ir3eob9gDvg88T-u38LJUz">Gestor de Memoria: Guía Rápida</a></li> 
            <li><a href="https://www.educatica.es/sistemas-operativos/principios-basicos/gestion-de-memoria/">Gestión de memoria en el sistema operativo</a></li> 
            <li><a href="https://es.wikipedia.org/wiki/Gesti%C3%B3n_de_memoria">Gestión de memoria</a></li> 
        </ul>',
    ],
];
