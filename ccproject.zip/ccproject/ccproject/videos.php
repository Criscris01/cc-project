<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Video</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&family=Rubik:ital,wght@0,300..900;1,300..900&display=swap" rel="stylesheet">
    <link rel="shortcut icon" href="./images/shotcut/nosotros.ico">

    <!-- Estilos específicos de la página de Videos -->
    <style>
        .main-video {
            flex: 1;
            padding: 2rem;
            background-color: #C1D3F6;
        }

        .welcome-section {
            text-align: center;
            padding: 1rem 2rem;
            background: #C1D3F6;
            border-radius: 12px;
            animation: fadeInUp 0.6s ease both;
            min-height: auto;
            margin-bottom: 2rem;
        }

        .welcome-section h1 {
            margin: 0;
            font-family: "Rubik", sans-serif;
            font-weight: 500;
            color: #0B214A;
            font-size: 2rem;
        }

        .welcome-section p {
            color: #0B214A;
            font-size: 1.1rem;
            line-height: 1.6;
            max-width: 900px;
            margin: 0 auto;
        }

        .video-card {
            display: flex;
            border-radius: 12px;
            overflow: hidden;
            background-color: #C1D3F6;
            box-shadow: 0 4px 8px rgba(11, 33, 74, 0.12);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            animation: fadeInUp 0.6s ease both;
            border: 1.5px solid #719BEA;
            margin: 0 auto 3rem auto;
            max-width: 1000px;
        }

        .video-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 12px rgba(21, 63, 142, 0.2);
        }

        .video-iframe {
            width: 50%;
            position: relative;
        }

        .video-iframe iframe {
            width: 100%;
            height: 100%;
            min-height: 280px;
        }

        .video-description {
            width: 50%;
            padding: 1rem 1.5rem;
            background-color: #C1D3F6;
            font-family: "Montserrat", sans-serif;
            color: #0B214A;
            box-sizing: border-box;
        }

        .video-description h2 {
            font-size: 1.8rem;
            margin: 0.25rem 0 0.5rem 0;
            font-family: "Rubik", sans-serif;
            font-weight: 500;
            text-align: center;
            position: relative;
        }

        .video-description h2::after {
            content: "";
            position: absolute;
            width: 0;
            height: 1px;
            bottom: -5px;
            left: 0;
            background-color: #2163DE;
            transition: width 0.3s ease;
        }

        .video-card:hover .video-description h2::after {
            width: 100%;
        }

        .video-description p {
            margin: 0.8rem 0;
            line-height: 1.6;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @media (max-width: 768px) {
            .video-card {
                flex-direction: column;
                margin: 0 auto 2rem auto;
                width: 100%;
                max-width: 100%;
                box-sizing: border-box;
                padding: 0 1rem;
            }

            .video-iframe,
            .video-description {
                width: 100%;
                box-sizing: border-box;
                margin: 0;
                padding: 0;
            }

            .video-iframe {
                padding: 0;
            }

            .video-iframe iframe {
                min-height: 220px;
                width: 100%;
                display: block;
            }

            .video-description {
                padding: 1.5rem 1rem;
                text-align: left;
                width: 100%;
            }

            .video-description h2 {
                font-size: 1.8rem;
                margin: 0.25rem 0 0.5rem 0;
                font-family: "Rubik", sans-serif;
                font-weight: 500;
                text-align: center;
                position: relative;
                width: 100%;
            }

            /* Mantener el efecto de la línea en móvil */
            .video-description h2::after {
                left: 0;
                transform: none;
                width: 0;
                height: 1px;
                bottom: -5px;
                background-color: #2163DE;
                transition: width 0.3s ease;
            }

            .video-card:hover .video-description h2::after {
                width: 100%;
            }

            .video-description p {
                margin: 0.8rem 0;
                line-height: 1.6;
                text-align: left;
                width: 100%;
            }
        }
    </style>
</head>

<body>
    <?php include "header.php"; ?>

    <main class="main-video">
        <section class="welcome-section">
            <h1>Para quienes no se conforman con el abrebocas</h1>
            <p>Si has llegado hasta aquí es porque tu sed de conocimiento va más allá de lo básico. Esta sección fue diseñada para curiosos como tú, para quienes entender solo la superficie nunca es suficiente. Sé que una mente inquieta busca profundizar, conectar conceptos y descubrir el porqué detrás del cómo.</p>
            <p>He reunido una selección rigurosa de videos que amplían y complementan cada tema explorado en el sitio. Aquí encontrarás explicaciones que profundizan en los detalles técnicos, entrevistas con expertos y casos prácticos que transforman la teoría en comprensión tangible. Además, incluyo contenidos adicionales sobre temas afines que, estoy seguro, despertarán tu interés y ampliarán tu panorama tecnológico.</p>
        </section>


        <div class="video-card">
            <div class="video-iframe">
                <iframe src="https://www.youtube.com/embed/fsuroRYmagw" frameborder="0" allowfullscreen></iframe>
            </div>
            <div class="video-description">
                <h2>Sistemas Operativos</h2>
                <p>El video explica qué es un sistema operativo, cómo funciona, sus partes principales y los tipos existentes para computadoras, móviles y dispositivos integrados, mostrando su importancia para controlar el hardware y ejecutar programas.</p>
            </div>
        </div>

        <div class="video-card">
            <div class="video-iframe">
                <iframe src="https://www.youtube.com/embed/gVaE2F0jOJs?si=e1k2XQIcH6Y5e8iv" frameborder="0" allowfullscreen></iframe>
            </div>
            <div class="video-description">
                <h2>Hardware y Software</h2>
                <p>El video explica qué son el hardware y el software, sus diferencias, tipos y funciones dentro de un ordenador, mostrando cómo ambos trabajan juntos para permitir su funcionamiento.</p>
            </div>
        </div>

        <div class="video-card">
            <div class="video-iframe">
                <iframe src="https://www.youtube.com/embed/b_jUyLyKW_s?si=0yLvdgBIC3MJg074" frameborder="0" allowfullscreen></iframe>
            </div>
            <div class="video-description">
                <h2>Estructura SO</h2>
                <p>El video explica las principales estructuras de los sistemas operativos: monolítica, jerárquica por capas y cliente-servidor, describiendo sus características, funcionamiento y cómo organizan procesos, memoria y comunicación entre componentes.</p>
            </div>
        </div>

        <div class="video-card">
            <div class="video-iframe">
                <iframe src="https://www.youtube.com/embed/iG2Spybc89U?si=WXkCm6il0GgjUVjS" frameborder="0" allowfullscreen></iframe>
            </div>
            <div class="video-description">
                <h2>Gestión de procesos</h2>
                <p>El video explica cómo la multiprogramación permite alternar procesos en la CPU, qué es un cambio de contexto, cómo se crean y terminan procesos en Unix (fork/exec) y Windows, y cómo se organiza la ejecución y finalización de procesos en un sistema operativo.</p>
            </div>
        </div>

        <div class="video-card">
            <div class="video-iframe">
                <iframe src="https://www.youtube.com/embed/n6IxKTS2zYs?si=ZpsN1YE2XXS9BzAe" frameborder="0" allowfullscreen></iframe>
            </div>
            <div class="video-description">
                <h2>Procesos e Hilos</h2>
                <p>El video explica qué es un proceso y qué es un hilo, sus diferencias, cómo gestionan recursos, cómo se ejecutan en la CPU y por qué son importantes para la programación concurrente y paralela.</p>
            </div>
        </div>

        <div class="video-card">
            <div class="video-iframe">
                <iframe src="https://www.youtube.com/embed/qbeSutu1rHg?si=ANOroJX0U2T3TtqV" frameborder="0" allowfullscreen></iframe>
            </div>
            <div class="video-description">
                <h2>Gestión de Memoria</h2>
                <p>El video explica cómo el sistema operativo administra la memoria, describe jerarquías, paginación, segmentación, memoria virtual, técnicas de E/S, archivos, atributos y directorios, destacando cómo estos mecanismos optimizan el uso de recursos y la organización del sistema.</p>
            </div>
        </div>

        <div class="video-card">
            <div class="video-iframe">
                <iframe src="https://www.youtube.com/embed/RVGIXfC4Xeg?si=SzKqrC58y4ZJWDLl" frameborder="0" allowfullscreen></iframe>
            </div>
            <div class="video-description">
                <h2>Sistema Binario y lógica</h2>
                <p>El video explica cómo la computación se basa en el sistema binario y en puertas lógicas. Muestra cómo los transistores representan ceros y unos, cómo se realizan operaciones básicas y cómo todo se transforma en números, colores, texto e información digital.</p>
            </div>
        </div>

        <div class="video-card">
            <div class="video-iframe">
                <iframe src="https://www.youtube.com/embed/3epohkSc0b4?si=r5JsN5NjQUsglQgh" frameborder="0" allowfullscreen></iframe>
            </div>
            <div class="video-description">
                <h2>Kernel SO</h2>
                <p>El video explica qué es el kernel, cómo controla hardware y tareas de bajo nivel, su relación con el sistema operativo, y las diferencias entre kernels monolíticos, microkernels e híbridos, mostrando sus ventajas, desventajas y funcionamiento básico.</p>
            </div>
        </div>

        <div class="video-card">
            <div class="video-iframe">
                <iframe src="https://www.youtube.com/embed/uiFZUfmFAus?si=K48aDaHfp6er-hZh" frameborder="0" allowfullscreen></iframe>
            </div>
            <div class="video-description">
                <h2>Máquinas virtuales</h2>
                <p>El video explica qué es una máquina virtual, cómo funciona VirtualBox, tipos de virtualización, uso de hypervisores, instalación de Ubuntu desde una ISO y por qué la virtualización es esencial para aprender Linux, Docker y practicar sin dañar el sistema real.</p>
            </div>
        </div>

        <div class="video-card">
            <div class="video-iframe">
                <iframe src="https://www.youtube.com/embed/fbNqVwJ2TGk?si=-jJPBtecbrR-Y0HT" frameborder="0" allowfullscreen></iframe>
            </div>
            <div class="video-description">
                <h2>Diferencias SO</h2>
                <p>El video explica diferencias entre Windows, Linux y macOS, su historia, filosofía, ventajas, desventajas, compatibilidad, seguridad, uso en servidores y elección según necesidades como desarrollo, uso general, hardware disponible y preferencias personales.</p>
            </div>
        </div>
    </main>

    <?php include "footer.php"; ?>

    <script src="menu.js"></script>
</body>

</html>